# ClipForge — file placement & setup

| File here | Copy to (in your `flutter create clipforge` project) |
|---|---|
| pubspec.yaml (dependencies block) | `pubspec.yaml`, then `flutter pub get` |
| lib/** | `lib/` |
| android/.../AndroidManifest.xml | `android/app/src/main/AndroidManifest.xml` (merge) |
| android/.../kotlin/com/example/clipforge/*.kt | same path (match your package name) |
| ios/Runner/RecorderBridge.swift | `ios/Runner/` (add to Runner target) |
| ios/Runner/Info.plist.additions.xml | merge keys into the two Info.plist files |
| ios/BroadcastExtension/SampleHandler.swift | new Xcode target: File > New > Target > Broadcast Upload Extension (no UI) |

## Gradle
`android/app/build.gradle`: minSdk 26, compileSdk 34+, targetSdk 34+.

## Clean-feed reality check
**Android.** MediaProjection captures the composited display, which includes
TYPE_APPLICATION_OVERLAY windows. There is no public "exclude this window" API.
FLAG_SECURE on the overlay is the best available trick, but results vary by OEM/OS
(skipped vs. black box). Test on target phones. Guaranteed-clean fallback: set
HIDE_OVERLAY_WHILE_RECORDING = true in RecorderService.kt and drive recording from the
notification buttons (Rec / Clip / Stop).

**iOS.** No floating overlay over other apps exists. System-wide capture requires a
Broadcast Upload Extension started from the system picker. Bookmark must come from
elsewhere: a Live Activity / App Intent button, Back Tap -> Shortcut, or the app,
which posts the `clipforge.bookmark` Darwin notification. The extension has a ~50 MB
memory cap, hence the on-disk segment ring.

## Not included (next steps)
- Game audio (AudioPlaybackCapture + AAC track in the same muxer; needs RECORD_AUDIO)
- Orientation change mid-recording (stop/start the recorder on rotate)
- Auto-trigger (e.g. goal detection): call the same bookmark() path
