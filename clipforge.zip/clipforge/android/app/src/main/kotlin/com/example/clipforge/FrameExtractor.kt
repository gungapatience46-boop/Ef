package com.example.clipforge

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import java.io.File

object FrameExtractor {
    /** Full-resolution PNG frames at [positionsMs] from a saved clip. */
    fun extract(video: String, positionsMs: List<Long>, outDir: File): List<String> {
        outDir.mkdirs()
        val r = MediaMetadataRetriever()
        val out = mutableListOf<String>()
        try {
            r.setDataSource(video)
            positionsMs.forEachIndexed { i, ms ->
                val bmp = r.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
                    ?: return@forEachIndexed
                val f = File(outDir, "frame_${i}_${ms}ms.png")
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bmp.recycle()
                out += f.path
            }
        } finally { r.release() }
        return out
    }
}
