package com.example.clipforge

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import java.io.File

class MainActivity : FlutterActivity() {
    private val reqProjection = 4242
    private var pending: MethodChannel.Result? = null

    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        val messenger = engine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "clipforge/recorder").setMethodCallHandler { call, result ->
            when (call.method) {
                "hasOverlayPermission" -> result.success(Settings.canDrawOverlays(this))
                "openOverlaySettings" -> {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                    result.success(null)
                }
                "startSession" -> {
                    pending = result
                    val mpm = getSystemService(MediaProjectionManager::class.java)
                    startActivityForResult(mpm.createScreenCaptureIntent(), reqProjection)
                }
                "stopSession" -> {
                    startService(RecorderService.intent(this, RecorderService.ACTION_SHUTDOWN))
                    result.success(null)
                }
                "bookmark" -> {
                    startService(RecorderService.intent(this, RecorderService.ACTION_BOOKMARK))
                    result.success(null)
                }
                "extractFrames" -> {
                    val video = call.argument<String>("video")!!
                    val pos = call.argument<List<Number>>("positionsMs")!!.map { it.toLong() }
                    Thread {
                        val dir = File(File(video).parentFile, "shots_extra_${System.currentTimeMillis()}")
                        val out = FrameExtractor.extract(video, pos, dir)
                        runOnUiThread { result.success(out) }
                    }.start()
                }
                else -> result.notImplemented()
            }
        }

        EventChannel(messenger, "clipforge/events").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(args: Any?, sink: EventChannel.EventSink) {
                RecorderService.listener = { sink.success(it) }
            }
            override fun onCancel(args: Any?) { RecorderService.listener = null }
        })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == reqProjection) {
            val ok = resultCode == RESULT_OK && data != null
            if (ok) {
                // Android 14+: service must be in the foreground with type mediaProjection
                // BEFORE getMediaProjection() is called (done inside the service).
                ContextCompat.startForegroundService(
                    this,
                    RecorderService.intent(this, RecorderService.ACTION_PREPARE)
                        .putExtra("code", resultCode).putExtra("data", data)
                )
            }
            pending?.success(ok); pending = null
        } else {
            @Suppress("DEPRECATION") super.onActivityResult(requestCode, resultCode, data)
        }
    }
}
