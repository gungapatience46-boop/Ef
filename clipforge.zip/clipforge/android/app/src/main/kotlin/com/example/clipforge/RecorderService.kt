package com.example.clipforge

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.roundToInt

/**
 * Foreground service that owns: MediaProjection -> VirtualDisplay -> H.264 encoder -> RingBuffer,
 * plus the draggable native overlay (Start / Stop / Bookmark).
 */
class RecorderService : Service() {

    companion object {
        const val ACTION_PREPARE = "prepare"
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_BOOKMARK = "bookmark"
        const val ACTION_SHUTDOWN = "shutdown"

        const val BUFFER_SECONDS = 30
        const val BITRATE = 8_000_000
        const val FPS = 60
        /** true = bar disappears while recording; control via notification buttons (guaranteed clean). */
        const val HIDE_OVERLAY_WHILE_RECORDING = false

        var listener: ((Map<String, Any?>) -> Unit)? = null
        fun intent(ctx: Context, action: String) =
            Intent(ctx, RecorderService::class.java).setAction(action)
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var encoder: MediaCodec? = null
    private var drainThread: Thread? = null
    @Volatile private var recording = false
    private val ring = RingBuffer(BUFFER_SECONDS * 1_000_000L)

    private var overlay: View? = null
    private var startBtn: TextView? = null
    private var stopBtn: TextView? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            ACTION_PREPARE -> prepare(i)
            ACTION_START -> startRecording()
            ACTION_STOP -> stopRecording()
            ACTION_BOOKMARK -> bookmark()
            ACTION_SHUTDOWN -> shutdown()
        }
        return START_NOT_STICKY
    }

    // ---------- session ----------
    private fun prepare(i: Intent) {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        goForeground()
        val code = i.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            i.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra("data")
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data!!).also {
            // Android 14+: callback MUST be registered before createVirtualDisplay()
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { shutdown() } }
            }, main)
        }
        showOverlay()
        emitState()
    }

    private fun shutdown() {
        val p = projection ?: run { stopSelf(); return }
        projection = null                       // guards re-entry from Callback.onStop
        stopRecording()
        overlay?.let { runCatching { wm.removeView(it) } }; overlay = null
        display?.release(); display = null
        p.stop()
        stopForeground(STOP_FOREGROUND_REMOVE)
        emit(mapOf("type" to "state", "session" to false, "recording" to false))
        stopSelf()
    }

    // ---------- capture ----------
    private fun startRecording() {
        val p = projection ?: return
        if (recording) return

        val m = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)   // current orientation
        val scale = minOf(1f, 1080f / minOf(m.widthPixels, m.heightPixels))
        val w = (m.widthPixels * scale).roundToInt() and 1.inv()        // encoder needs even dims
        val h = (m.heightPixels * scale).roundToInt() and 1.inv()

        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, BITRATE)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)   // 1 key frame/sec => clip starts within 1s of target
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface = enc.createInputSurface()
        enc.start()

        // Android 14+ allows only ONE createVirtualDisplay per projection token,
        // so later Start taps re-use the display and just swap its output surface.
        if (display == null) {
            display = p.createVirtualDisplay("clipforge", w, h, m.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null)
        } else {
            display!!.resize(w, h, m.densityDpi)
            display!!.surface = surface
        }

        encoder = enc
        ring.clear()
        recording = true
        drainThread = Thread({ drain(enc) }, "clipforge-drain").also { it.start() }
        refreshUi()
    }

    private fun drain(enc: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        while (recording) {
            val idx = try { enc.dequeueOutputBuffer(info, 10_000) } catch (_: Exception) { break }
            when {
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> ring.format = enc.outputFormat
                idx >= 0 -> {
                    val buf = enc.getOutputBuffer(idx)
                    if (buf != null && info.size > 0 &&
                        info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                        val arr = ByteArray(info.size)
                        buf.position(info.offset); buf.limit(info.offset + info.size); buf.get(arr)
                        ring.add(Sample(arr, info.presentationTimeUs, info.flags))
                    }
                    enc.releaseOutputBuffer(idx, false)
                }
            }
        }
    }

    private fun stopRecording() {
        if (!recording) return
        recording = false
        drainThread?.join(500); drainThread = null
        display?.surface = null
        runCatching { encoder?.stop() }; encoder?.release(); encoder = null
        refreshUi()
    }

    // ---------- highlight trigger ----------
    private fun bookmark() {
        if (!recording) return
        val snap = ring.snapshot() ?: return
        toast("Saving last ${BUFFER_SECONDS}s…")
        Thread {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)!!.apply { mkdirs() }
            val stamp = System.currentTimeMillis()
            val out = File(dir, "clip_$stamp.mp4")
            ClipWriter.write(snap, out)
            val durMs = (snap.samples.last().ptsUs - snap.samples.first().ptsUs) / 1000
            // Celebration frames: 1s, 3s, 5s before the bookmark moment.
            val frames = FrameExtractor.extract(
                out.path, listOf(durMs - 1000, durMs - 3000, durMs - 5000).filter { it >= 0 },
                File(dir, "shots_$stamp"))
            emit(mapOf("type" to "clip", "video" to out.path, "durationMs" to durMs, "frames" to frames))
            main.post { toast("Highlight saved") }
        }.start()
    }

    // ---------- overlay ----------
    private fun showOverlay() {
        if (overlay != null) return
        val d = resources.displayMetrics.density
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                // Asks the compositor to keep this window out of non-secure captures.
                // Behaviour is OEM/OS dependent (may be skipped OR drawn black) — test on target devices.
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (16 * d).toInt(); y = (160 * d).toInt() }

        fun circle(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
            layoutParams = LinearLayout.LayoutParams((40 * d).toInt(), (40 * d).toInt())
                .apply { setMargins((3 * d).toInt(), 0, (3 * d).toInt(), 0) }
            setOnClickListener { onClick() }
        }

        val handle = TextView(this).apply {
            text = "⠿"; setTextColor(Color.LTGRAY); textSize = 20f
            setPadding((6 * d).toInt(), 0, (6 * d).toInt(), 0)
        }
        startBtn = circle("▶", 0xFF2E7D32.toInt()) { startRecording() }
        stopBtn = circle("■", 0xFFC62828.toInt()) { stopRecording() }
        val markBtn = circle("★", 0xFFF9A825.toInt()) { bookmark() }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding((6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
            background = GradientDrawable().apply { cornerRadius = 28 * d; setColor(0xB0000000.toInt()) }
            addView(handle); addView(startBtn); addView(stopBtn); addView(markBtn)
        }

        handle.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt(); lp.y = sy + (e.rawY - ty).toInt()
                        wm.updateViewLayout(row, lp)
                    }
                }
                return true
            }
        })

        wm.addView(row, lp)
        overlay = row
        refreshUi()
    }

    private fun refreshUi() {
        main.post {
            startBtn?.alpha = if (recording) 0.3f else 1f
            stopBtn?.alpha = if (recording) 1f else 0.3f
            overlay?.visibility = if (HIDE_OVERLAY_WHILE_RECORDING && recording) View.GONE else View.VISIBLE
            emitState()
        }
    }

    // ---------- plumbing ----------
    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rec", "Recorder", NotificationManager.IMPORTANCE_LOW))
        fun act(a: String, label: String, icon: Int) = Notification.Action.Builder(
            Icon.createWithResource(this, icon), label,
            PendingIntent.getService(this, a.hashCode(), intent(this, a),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)).build()
        val n = Notification.Builder(this, "rec")
            .setContentTitle("ClipForge").setContentText("Clean-feed recorder ready")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true)
            .addAction(act(ACTION_START, "Rec", android.R.drawable.ic_media_play))
            .addAction(act(ACTION_BOOKMARK, "Clip", android.R.drawable.btn_star))
            .addAction(act(ACTION_STOP, "Stop", android.R.drawable.ic_media_pause))
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun emitState() = emit(mapOf("type" to "state", "session" to (projection != null), "recording" to recording))
    private fun emit(m: Map<String, Any?>) { main.post { listener?.invoke(m) } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() { shutdown(); super.onDestroy() }
}
