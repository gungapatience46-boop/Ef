package com.example.clipforge

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

class Sample(val data: ByteArray, val ptsUs: Long, val flags: Int) {
    val isKey get() = flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
}

data class Snapshot(val samples: List<Sample>, val format: MediaFormat)

/**
 * Holds the last [windowUs] of ENCODED H.264 samples (~30 MB for 30 s @ 8 Mbps).
 * The head is always trimmed to a key frame, so any snapshot is independently decodable.
 */
class RingBuffer(private val windowUs: Long) {
    private val q = ArrayDeque<Sample>()
    @Volatile var format: MediaFormat? = null

    @Synchronized fun add(s: Sample) {
        q.addLast(s)
        if (s.isKey) trim(s.ptsUs)   // only re-trim on key frames (cheap)
    }

    private fun trim(newest: Long) {
        val cutoff = newest - windowUs
        var k = -1
        for (i in q.indices) {
            if (q[i].ptsUs > cutoff) break
            if (q[i].isKey) k = i
        }
        repeat(maxOf(k, 0)) { q.removeFirst() }
    }

    @Synchronized fun snapshot(): Snapshot? {
        val f = format ?: return null
        return if (q.isEmpty()) null else Snapshot(q.toList(), f)
    }

    @Synchronized fun clear() = q.clear()
}

object ClipWriter {
    /** Remuxes encoded samples into an MP4 — no re-encode, so it's instant. */
    fun write(s: Snapshot, out: File) {
        val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val track = mux.addTrack(s.format)
        mux.start()
        val base = s.samples.first().ptsUs
        val info = MediaCodec.BufferInfo()
        for (x in s.samples) {
            info.set(0, x.data.size, x.ptsUs - base, x.flags)
            mux.writeSampleData(track, ByteBuffer.wrap(x.data), info)
        }
        mux.stop(); mux.release()
    }
}
