import ReplayKit
import AVFoundation

/// Broadcast Upload Extension (system-wide capture). STUB: segment-ring approach.
/// Extensions are capped at ~50 MB RAM, so we stream 5 s MP4 segments to disk
/// and keep the newest 7 (>= 30 s). A bookmark concatenates the newest 6.
class SampleHandler: RPBroadcastSampleHandler {
    private let group = FileManager.default.containerURL(
        forSecurityApplicationGroupIdentifier: "group.com.example.clipforge")!
    private let segSeconds = 5.0, keep = 7, clipSegments = 6
    private var writer: AVAssetWriter?
    private var input: AVAssetWriterInput?
    private var segStart = CMTime.invalid
    private var segments: [URL] = []
    private let q = DispatchQueue(label: "clipforge.seg")

    override func broadcastStarted(withSetupInfo setupInfo: [String: NSObject]?) {
        // Bookmark requests come from the app / App Intent / Live Activity button.
        CFNotificationCenterAddObserver(
            CFNotificationCenterGetDarwinNotifyCenter(), Unmanaged.passUnretained(self).toOpaque(),
            { _, obs, _, _, _ in
                guard let obs = obs else { return }
                Unmanaged<SampleHandler>.fromOpaque(obs).takeUnretainedValue().bookmark()
            }, "clipforge.bookmark" as CFString, nil, .deliverImmediately)
    }

    override func processSampleBuffer(_ sb: CMSampleBuffer, with type: RPSampleBufferType) {
        guard type == .video, CMSampleBufferDataIsReady(sb) else { return }
        q.sync {
            let pts = CMSampleBufferGetPresentationTimeStamp(sb)
            if writer == nil || CMTimeGetSeconds(pts - segStart) >= segSeconds { rotate(pts, sb) }
            if input?.isReadyForMoreMediaData == true { input?.append(sb) }
        }
    }

    private func rotate(_ pts: CMTime, _ sb: CMSampleBuffer) {
        input?.markAsFinished(); writer?.finishWriting {}
        while segments.count >= keep { try? FileManager.default.removeItem(at: segments.removeFirst()) }

        let url = group.appendingPathComponent("seg_\(Int(Date().timeIntervalSince1970 * 1000)).mp4")
        let d = CMVideoFormatDescriptionGetDimensions(CMSampleBufferGetFormatDescription(sb)!)
        let w = try! AVAssetWriter(url: url, fileType: .mp4)
        let i = AVAssetWriterInput(mediaType: .video, outputSettings: [
            AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: d.width, AVVideoHeightKey: d.height,
            AVVideoCompressionPropertiesKey: [AVVideoAverageBitRateKey: 8_000_000]])
        i.expectsMediaDataInRealTime = true
        w.add(i); w.startWriting(); w.startSession(atSourceTime: pts)
        writer = w; input = i; segStart = pts; segments.append(url)
    }

    private func bookmark() {
        q.async {
            let urls = Array(self.segments.dropLast().suffix(self.clipSegments)) // finished segments only
            guard !urls.isEmpty else { return }
            let comp = AVMutableComposition()
            guard let track = comp.addMutableTrack(withMediaType: .video, preferredTrackID: kCMPersistentTrackID_Invalid)
            else { return }
            var t = CMTime.zero
            for u in urls {
                let a = AVAsset(url: u)
                guard let src = a.tracks(withMediaType: .video).first else { continue }
                try? track.insertTimeRange(CMTimeRange(start: .zero, duration: a.duration), of: src, at: t)
                t = t + a.duration
            }
            let out = self.group.appendingPathComponent("clip_\(Int(Date().timeIntervalSince1970 * 1000)).mp4")
            guard let ex = AVAssetExportSession(asset: comp, presetName: AVAssetExportPresetPassthrough) else { return }
            ex.outputURL = out; ex.outputFileType = .mp4
            ex.exportAsynchronously {
                let meta: [String: Any] = ["video": out.path, "durationMs": Int64(CMTimeGetSeconds(t) * 1000)]
                try? JSONSerialization.data(withJSONObject: meta)
                    .write(to: self.group.appendingPathComponent("latest.json"))
                CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                    CFNotificationName("clipforge.clipSaved" as CFString), nil, nil, true)
            }
        }
    }

    override func broadcastFinished() { input?.markAsFinished(); writer?.finishWriting {} }
}
