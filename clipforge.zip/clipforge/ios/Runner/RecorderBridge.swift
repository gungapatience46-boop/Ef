import Flutter
import ReplayKit
import AVFoundation
import UIKit

/// Add to AppDelegate.didFinishLaunching:
///   RecorderBridge.shared.register(with: (window?.rootViewController as! FlutterViewController).binaryMessenger)
final class RecorderBridge: NSObject, FlutterStreamHandler {
    static let shared = RecorderBridge()
    static let appGroup = "group.com.example.clipforge"
    static let extensionBundleId = "com.example.clipforge.BroadcastExtension"
    private var sink: FlutterEventSink?

    func register(with messenger: FlutterBinaryMessenger) {
        let ch = FlutterMethodChannel(name: "clipforge/recorder", binaryMessenger: messenger)
        ch.setMethodCallHandler { [weak self] call, result in
            switch call.method {
            case "hasOverlayPermission": result(true)          // iOS has no system-wide overlay
            case "openOverlaySettings": result(nil)
            case "startSession": self?.presentPicker(); result(true)
            case "stopSession": self?.post("clipforge.stop"); result(nil)
            case "bookmark": self?.post("clipforge.bookmark"); result(nil)
            case "extractFrames":
                let a = call.arguments as! [String: Any]
                let url = URL(fileURLWithPath: a["video"] as! String)
                let ms = (a["positionsMs"] as! [NSNumber]).map { $0.int64Value }
                DispatchQueue.global().async {
                    let out = Self.extract(url, ms)
                    DispatchQueue.main.async { result(out) }
                }
            default: result(FlutterMethodNotImplemented)
            }
        }
        FlutterEventChannel(name: "clipforge/events", binaryMessenger: messenger).setStreamHandler(self)

        // Extension -> app: "a clip was written" (Darwin notification, payload in App Group)
        CFNotificationCenterAddObserver(
            CFNotificationCenterGetDarwinNotifyCenter(), Unmanaged.passUnretained(self).toOpaque(),
            { _, obs, _, _, _ in
                guard let obs = obs else { return }
                Unmanaged<RecorderBridge>.fromOpaque(obs).takeUnretainedValue().clipSaved()
            }, "clipforge.clipSaved" as CFString, nil, .deliverImmediately)
    }

    private func presentPicker() {
        DispatchQueue.main.async {
            let picker = RPSystemBroadcastPickerView(frame: CGRect(x: 0, y: 0, width: 1, height: 1))
            picker.preferredExtension = Self.extensionBundleId
            picker.showsMicrophoneButton = false
            UIApplication.shared.keyWindow?.addSubview(picker)
            (picker.subviews.first { $0 is UIButton } as? UIButton)?.sendActions(for: .allTouchEvents)
        }
    }

    private func post(_ name: String) {
        CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
            CFNotificationName(name as CFString), nil, nil, true)
    }

    private func clipSaved() {
        guard let dir = FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: Self.appGroup),
              let data = try? Data(contentsOf: dir.appendingPathComponent("latest.json")),
              var m = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
        m["type"] = "clip"
        let video = URL(fileURLWithPath: m["video"] as! String)
        let dur = (m["durationMs"] as? Int64) ?? 30_000
        m["frames"] = Self.extract(video, [dur - 1000, dur - 3000, dur - 5000].filter { $0 >= 0 })
        DispatchQueue.main.async { self.sink?(m) }
    }

    static func extract(_ url: URL, _ positionsMs: [Int64]) -> [String] {
        let gen = AVAssetImageGenerator(asset: AVAsset(url: url))
        gen.appliesPreferredTrackTransform = true
        gen.requestedTimeToleranceBefore = .zero; gen.requestedTimeToleranceAfter = .zero  // full-res, exact frame
        return positionsMs.enumerated().compactMap { i, ms in
            guard let cg = try? gen.copyCGImage(at: CMTime(value: ms, timescale: 1000), actualTime: nil),
                  let png = UIImage(cgImage: cg).pngData() else { return nil }
            let f = url.deletingLastPathComponent().appendingPathComponent("frame_\(i)_\(ms)ms.png")
            try? png.write(to: f); return f.path
        }
    }

    func onListen(withArguments a: Any?, eventSink e: @escaping FlutterEventSink) -> FlutterError? { sink = e; return nil }
    func onCancel(withArguments a: Any?) -> FlutterError? { sink = nil; return nil }
}
