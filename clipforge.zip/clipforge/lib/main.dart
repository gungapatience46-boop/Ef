import 'package:flutter/material.dart';
import 'ui/screens/home_screen.dart';

void main() => runApp(const ClipForgeApp());

class ClipForgeApp extends StatelessWidget {
  const ClipForgeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'ClipForge',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: const HomeScreen(),
      );
}
