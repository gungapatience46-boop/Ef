class Clip {
  final String videoPath;
  final List<String> frames; // PNG paths
  final int durationMs;
  final DateTime createdAt;

  Clip({required this.videoPath, required this.frames, required this.durationMs, DateTime? createdAt})
      : createdAt = createdAt ?? DateTime.now();

  factory Clip.fromMap(Map<String, dynamic> m) => Clip(
        videoPath: m['video'] as String,
        frames: List<String>.from(m['frames'] as List? ?? const []),
        durationMs: (m['durationMs'] as num?)?.toInt() ?? 0,
      );
}
