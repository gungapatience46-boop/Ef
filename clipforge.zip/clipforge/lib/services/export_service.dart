import 'package:gal/gal.dart';
import '../models/clip.dart';

/// Copies clips and screenshots into the device gallery (MediaStore / Photos).
class ExportService {
  static const album = 'ClipForge';

  Future<void> _ensureAccess() async {
    if (!await Gal.hasAccess(toAlbum: true)) {
      if (!await Gal.requestAccess(toAlbum: true)) {
        throw Exception('Gallery access denied');
      }
    }
  }

  Future<void> saveVideo(String path) async {
    await _ensureAccess();
    await Gal.putVideo(path, album: album);
  }

  Future<void> saveImage(String path) async {
    await _ensureAccess();
    await Gal.putImage(path, album: album);
  }

  /// Post-match export: the clip plus every extracted screenshot.
  Future<void> exportClip(Clip c) async {
    await saveVideo(c.videoPath);
    for (final f in c.frames) {
      await saveImage(f);
    }
  }
}
