import 'dart:async';
import 'package:flutter/services.dart';

/// Thin Dart wrapper over the native recorder (Kotlin on Android, Swift on iOS).
/// Hot-path actions (start / stop / bookmark) happen from the native overlay or
/// notification, so they keep working while Flutter is in the background.
class RecorderService {
  static const _method = MethodChannel('clipforge/recorder');
  static const _events = EventChannel('clipforge/events');

  /// {type:'clip', video, durationMs, frames[]} | {type:'state', session, recording}
  Stream<Map<String, dynamic>> get events => _events
      .receiveBroadcastStream()
      .map((e) => Map<String, dynamic>.from(e as Map));

  Future<bool> hasOverlayPermission() async =>
      (await _method.invokeMethod<bool>('hasOverlayPermission')) ?? false;

  Future<void> openOverlaySettings() => _method.invokeMethod('openOverlaySettings');

  /// Android: shows the MediaProjection consent dialog, starts the foreground
  /// service and the floating bar. iOS: presents the broadcast picker.
  Future<bool> startSession() async =>
      (await _method.invokeMethod<bool>('startSession')) ?? false;

  Future<void> stopSession() => _method.invokeMethod('stopSession');

  Future<void> bookmark() => _method.invokeMethod('bookmark');

  /// Extra hi-res frames from a saved clip (positions in ms).
  Future<List<String>> extractFrames(String videoPath, List<int> positionsMs) async =>
      (await _method.invokeListMethod<String>(
              'extractFrames', {'video': videoPath, 'positionsMs': positionsMs})) ??
      const [];
}
