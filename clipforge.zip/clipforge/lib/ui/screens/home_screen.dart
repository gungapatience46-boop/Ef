import 'dart:async';
import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../models/clip.dart';
import '../../services/export_service.dart';
import '../../services/recorder_service.dart';
import '../../widgets/clip_tile.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _rec = RecorderService();
  final _export = ExportService();
  final _clips = <Clip>[];
  StreamSubscription? _sub;
  bool _session = false;

  @override
  void initState() {
    super.initState();
    _sub = _rec.events.listen((e) {
      if (!mounted) return;
      setState(() {
        if (e['type'] == 'clip') _clips.insert(0, Clip.fromMap(e));
        if (e['type'] == 'state') _session = e['session'] as bool? ?? false;
      });
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _begin() async {
    if (Platform.isAndroid) {
      await Permission.notification.request();
      if (!await _rec.hasOverlayPermission()) {
        await _rec.openOverlaySettings(); // user toggles "Display over other apps"
        _snack('Enable the overlay permission, then come back and tap again.');
        return;
      }
    }
    await _rec.startSession();
  }

  Future<void> _exportClip(Clip c) async {
    try {
      await _export.exportClip(c);
      _snack('Saved to gallery (album: ${ExportService.album})');
    } catch (e) {
      _snack('Export failed: $e');
    }
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('ClipForge')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              FilledButton(
                onPressed: _session ? _rec.stopSession : _begin,
                child: Text(_session ? 'End session' : 'Start session'),
              ),
              const SizedBox(height: 8),
              const Text(
                'Open your game, then use the floating bar:  ▶ record   ■ stop   ★ save last 30s',
                textAlign: TextAlign.center,
              ),
            ]),
          ),
          Expanded(
            child: ListView(children: [
              for (final c in _clips) ClipTile(clip: c, onExportAll: () => _exportClip(c)),
            ]),
          ),
        ]),
      );
}
