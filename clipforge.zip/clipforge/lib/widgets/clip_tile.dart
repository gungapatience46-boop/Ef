import 'dart:io';
import 'package:flutter/material.dart';
import '../models/clip.dart';

class ClipTile extends StatelessWidget {
  final Clip clip;
  final VoidCallback onExportAll;
  const ClipTile({super.key, required this.clip, required this.onExportAll});

  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Highlight • ${(clip.durationMs / 1000).toStringAsFixed(0)}s',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            if (clip.frames.isNotEmpty)
              SizedBox(
                height: 70,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    for (final f in clip.frames)
                      Padding(
                        padding: const EdgeInsets.only(right: 6),
                        child: Image.file(File(f), fit: BoxFit.cover),
                      ),
                  ],
                ),
              ),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                onPressed: onExportAll,
                icon: const Icon(Icons.save_alt),
                label: const Text('Save to gallery'),
              ),
            ),
          ]),
        ),
      );
}
